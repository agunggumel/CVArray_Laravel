    

   
   

    <?php $__env->startSection('kontenhome'); ?>
    <h1><?php echo e($homename1); ?></h1>
    <h1><?php echo e($homename2); ?></h1>
    <p><span class="typed" data-typed-items="<?php echo e($animasi1); ?>, <?php echo e($animasi2); ?>"></span></p>
    <?php $__env->stopSection(); ?>


    <?php $__env->startSection('kontenprofil'); ?>
    <div class="section-title">
                    <h2><?php echo e($Profil); ?></h2>
                </div>
                <div class="row">
                    <div class="col-lg-3" data-aos="fade-right">
                        <img src="assets/img/profile-img.jpg" class="img-fluid" alt="">
                    </div>
        
                    <div class="col-lg-8 pt-4 pt-lg-0 content" data-aos="fade-left">
                        <div class="row">
                            <div class="col-lg-6">
                                 <ul>
                                 <li><i class="bi bi-chevron-right"></i> <strong>Nama Lengkap:</strong> <span> <?php echo e($Nama); ?></span></li>
                                 <li><i class="bi bi-chevron-right"></i> <strong>Tempat Tanggal Lahir:</strong> <span> <?php echo e($ttl); ?></span></li>
                                 <li><i class="bi bi-chevron-right"></i> <strong>Tinggi Badan: </strong> <span> <?php echo e($tinggi); ?></span></li>
                                <li><i class="bi bi-chevron-right"></i> <strong>Berat Badan:</strong> <span> <?php echo e($berat); ?></span></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
    <?php $__env->stopSection(); ?>



    <?php $__env->startSection('kontenSoftskills'); ?>
    <div class="container">

        <div class="section-title">
        <h2><?php echo e($soft); ?></h2>
        </div>

            <div class="row no-gutters">

                <div class="col-lg-3 col-md-6 d-md-flex align-items-md-stretch" data-aos="fade-up">
                    <div class="count-box">
                        <i class="bi bi-people"></i>
                        <span data-purecounter-start="0" data-purecounter-end="99" data-purecounter-duration="1" class="purecounter"></span>
                        <p><strong><?php echo e($s1); ?></strong> </p>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 d-md-flex align-items-md-stretch" data-aos="fade-up" data-aos-delay="100">
                    <div class="count-box">
                        <i class="bi bi-people"></i>
                        <span data-purecounter-start="0" data-purecounter-end="100" data-purecounter-duration="1" class="purecounter"></span>
                        <p><strong><?php echo e($s2); ?></strong></p>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 d-md-flex align-items-md-stretch" data-aos="fade-up" data-aos-delay="200">
                    <div class="count-box">
                        <i class="bi bi-people"></i>
                        <span data-purecounter-start="0" data-purecounter-end="94" data-purecounter-duration="1" class="purecounter"></span>
                        <p><strong><?php echo e($s3); ?></strong></p>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 d-md-flex align-items-md-stretch" data-aos="fade-up" data-aos-delay="300">
                    <div class="count-box">
                        <i class="bi bi-people"></i>
                        <span data-purecounter-start="0" data-purecounter-end="89" data-purecounter-duration="1" class="purecounter"></span>
                        <p><strong><?php echo e($s4); ?></strong></p>
                    </div>
                </div>

            </div>

    </div>
    <?php $__env->stopSection(); ?>


    <?php $__env->startSection('kontenHardskills'); ?>
        <div class="container">
            <div class="section-title">
                <h2><?php echo e($hard); ?></h2>
            </div>

                <div class="row skills-content">
                    <div class="col-lg-6" data-aos="fade-up">
                        <div class="progress">
                        <span class="skill"><?php echo e($h1); ?><i class="val">75%</i></span>
                            <div class="progress-bar-wrap">
                                <div class="progress-bar" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>

                        <div class="progress">
                        <span class="skill"><?php echo e($h2); ?> <i class="val">90%</i></span>
                            <div class="progress-bar-wrap">
                                <div class="progress-bar" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>

                        <div class="progress">
                        <span class="skill"><?php echo e($h3); ?> <i class="val">90%</i></span>
                            <div class="progress-bar-wrap">
                                <div class="progress-bar" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>

                        <div class="progress">
                        <span class="skill"><?php echo e($h4); ?> <i class="val">70%</i></span>
                            <div class="progress-bar-wrap">
                                <div class="progress-bar" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-6" data-aos="fade-up" data-aos-delay="100">

                        <div class="progress">
                        <span class="skill"><?php echo e($h5); ?><i class="val">70%</i></span>
                            <div class="progress-bar-wrap">
                                <div class="progress-bar" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>

                        <div class="progress">
                        <span class="skill"><?php echo e($h6); ?> <i class="val">90%</i></span>
                            <div class="progress-bar-wrap">
                                <div class="progress-bar" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>

                        <div class="progress">
                        <span class="skill"><?php echo e($h7); ?><i class="val">90%</i></span>
                            <div class="progress-bar-wrap">
                                <div class="progress-bar" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>

                        <div class="progress">
                        <span class="skill"><?php echo e($h8); ?> <i class="val">80%</i></span>
                            <div class="progress-bar-wrap">
                                <div class="progress-bar" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                </div>
        </div>
    <?php $__env->stopSection(); ?>


    <?php $__env->startSection('kontenPengalaman'); ?>
    <div class="row">
          <div class="col-lg-6" data-aos="fade-up">


            <h3 class="resume-title"><?php echo e($org); ?></h3>
            
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="resume-item pb-0">
                <h4><?php echo e($post["name_organisasi"]); ?> </h4>
                <p><em><?php echo e($post["Des"]); ?></em></p>
                 </div>
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <h3 class="resume-title"><?php echo e($pen); ?></h3>

            <?php $__currentLoopData = $posts1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="resume-item">
            <h4><?php echo e($post ["name_pen"]); ?></h4>
              <h5><?php echo e($post ["thn"]); ?></h5>
              <p><em><?php echo e($post ["des1"]); ?>

              </em></p>
              <p><em><?php echo e($post ["des2"]); ?>

              </em></p>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
           
          </div>
          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="100">
            <h3 class="resume-title"><?php echo e($ker); ?></h3>
           

            <?php $__currentLoopData = $posts2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="resume-item">
              <h4><?php echo e($post ["name_ker"]); ?></h4>
              <h5><?php echo e($post ["thn"]); ?></h5>
              <ul>
                <p><em><?php echo e($post ["des1"]); ?></em></p>
                <p><em><?php echo e($post ["des2"]); ?></em></p>
                <p><em><?php echo e($post ["des3"]); ?></em></p>
              </ul>
            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         

          </div>
        </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Curiculum Vitae\CuriculumVitae\resources\views/Konten.blade.php ENDPATH**/ ?>