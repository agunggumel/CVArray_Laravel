    
    

    <?php $__env->startSection('home'); ?>
    <h1>Agung Gumelar</h1>
    <h1>Firmansyah</h1>
    <p><span class="typed" data-typed-items="S1 Informatika, Universitas Widyatama"></span></p>
    <?php $__env->stopSection(); ?>


    <?php $__env->startSection('homeprofil'); ?>
    <div class="section-title">
                    <h2>Profil</h2>
                </div>
                <div class="row">
                    <div class="col-lg-3" data-aos="fade-right">
                        <img src="assets/img/profile-img.jpg" class="img-fluid" alt="">
                    </div>
        
                    <div class="col-lg-8 pt-4 pt-lg-0 content" data-aos="fade-left">
                        <div class="row">
                            <div class="col-lg-6">
                                 <ul>
                                 <li><i class="bi bi-chevron-right"></i> <strong>Nama Lengkap:</strong> <span> Agung Gumelar Firmansyah</span></li>
                                 <li><i class="bi bi-chevron-right"></i> <strong>Tempat Tanggal Lahir:</strong> <span> Subang, 22 Maret 1999</span></li>
                                 <li><i class="bi bi-chevron-right"></i> <strong>Tinggi Badan: </strong> <span> 167 cm</span></li>
                                <li><i class="bi bi-chevron-right"></i> <strong>Berat Badan:</strong> <span> 50 kg</span></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Curiculum Vitae\CuriculumVitae\resources\views/Home.blade.php ENDPATH**/ ?>